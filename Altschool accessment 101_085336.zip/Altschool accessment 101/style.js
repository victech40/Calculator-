document.addEventListener("DOMContentLoaded", function () {
  const display = document.getElementById("display");
  const buttons = document.querySelectorAll(".btn");
  const equals = document.getElementById("equals");
  const clear = document.getElementById("clear");
  const backspace = document.getElementById("backspace");

  // Initialize display
  display.textContent = "";

  function updateDisplay(value) {
    display.textContent += value;
  }

  // Handle number and operator buttons
  buttons.forEach((button) => {
    button.addEventListener("click", () => {
      const value = button.textContent;

      // Skip special buttons as they have their own handlers
      if (value === "=" || value === "←" || value === "C") return;

      updateDisplay(value);
    });
  });

  function evaluateExpression() {
    try {
      const result = eval(
        display.textContent
          .replace("×", "*")
          .replace("÷", "/")
          .replace("^", "**")
          .replace("%", "/100")
      );
      display.textContent = Number.isInteger(result)
        ? result
        : result.toFixed(2);
    } catch (error) {
      display.textContent = "Error";
    }
  }

  // Handle equals button
  equals.addEventListener("click", evaluateExpression);

  // Handle clear button
  clear.addEventListener("click", () => {
    display.textContent = "";
  });

  // Handle backspace button
  backspace.addEventListener("click", () => {
    display.textContent = display.textContent.slice(0, -1);
  });
});
